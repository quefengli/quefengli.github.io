#' @title Classify new samples based on the integrative linear discriminant analysis rule
#' @description Classify a new sample to class 0 if and only if \eqn{\hat{\beta}^T\{x-(\hat{\mu}_0 + \hat{\mu}_1)/2\} +
#'   \log(\hat{\pi}_0 / \hat{\pi}_1)\geq 0}, where \eqn{\hat{\beta}} is the solution of the iLDA problem, \eqn{x} is the
#'   vector of the new sample, \eqn{\hat{\mu}_0} and \eqn{\hat{\mu}_1} are the estimators of the means of the two classes,
#'   and \eqn{\hat{\pi}_0} and \eqn{\hat{\pi}_1} are the estimators of the prior probabilities of the two classes.
#' @param obj an object returned by \code{\link{iLDA}}.
#' @param new.X a matrix of new samples to be classified. Rows are samples and columns are features.
#' @param balanced a logical flag of whether the two classes have equal prior probability. If \code{balanced = TRUE},
#'   enforce \eqn{\hat{\pi}_0 = \hat{\pi}_1 = 1/2}; otherwise, use the estimators returned by \code{\link{iLDA}}.
#' @return a vector of predicted class labels of the new samples.
#' @export

## classify a new object using iLDA rule
classify <- function(obj,               # fit object from iLDA
                     new.X,             # new x
                     balanced = T       # whether adjust for unbalanced sample sizes of the two classes
                     ) {
  muhat    <- obj$mu
  betahat  <- obj$beta   
  X.minus.mu <- sweep(new.X, 2, muhat, '-')

  X.minus.mu[is.na(X.minus.mu)] <- 0
  
  if (balanced) {
    isone <- as.numeric(X.minus.mu %*% betahat < 0)
  } else {
    isone <- as.numeric(X.minus.mu %*% betahat + obj$w0 < 0)
  }

  return(as.vector(isone))
}

