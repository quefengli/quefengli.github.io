#' @title Cross-validation to choose the optimal tuning parameters
#' @description Choose the optimal tuning parameters in the integrative linear discriminant analysis (iLDA) problem by the
#'   K-fold cross-validation.
#' @param Y a vector of class labels.
#' @param X a matrix of samples. The dimension is \eqn{nobs * nvars}, where \eqn{nobs} is the sample size in the training
#'   set and \eqn{nvars} is number of features in all modalities. In practice, \code{cbind} data from all modalities to
#'   render \code{X}.
#' @param group a list of group indices. Each element in the list is the column indices of variables belonging to that
#'   group in \code{X} . See an example in \code{Examples} of \code{\link{iLDA}}.
#' @param alpha.grid the search grip of \eqn{\alpha}.
#' @param lambda.grid the search grip of \eqn{\lambda}.
#' @param K number of folds in cross-validation.
#' @param missing a logical flag of whether \code{X} contains missing values.
#' @param robust a logical flag of whether using robust estimators for \eqn{\mu_0}, \eqn{\mu_1} and \eqn{\Sigma}. If
#'   \code{TRUE}, the Huber robust estimators will be used. For more details, please see the reference.
#' @param k robustification factor in the Huber estimator.
#' @param tol tolerance level for stopping the algorithm.
#' @param max.iter maximum number of iterations allowed.
#' @param balanced see definition in \code{\link{classify}}.
#' @return a list with elements \item{best.alpha}{best value of \eqn{\alpha}.} \item{best.lambda}{best value of
#'   \eqn{\lambda}.} \item{cv.error}{a matrix of cross-validated misclassification rates.}
#' @import doParallel
#' @import foreach
#' @export

## source('generate.cv.idx.R')
## require(doParallel)
## require(foreach)

cv.iLDA <- function(Y,                  # binary response
                    X,                  # features for classification
                    group,              # list of group membership
                    alpha.grid,         # searching grid of alpha
                    lambda.grid,        # searching gird of lambda
                    K          = 5,     # K-fold CV
                    missing    = F,     # if there are missing values in X
                    robust     = F,     # if use robust estimator for mu and Sigma
                    k          = 1.345, # winsorized factor in the Huber estimator
                    tol        = 1e-3,  # tolerance level for convergence
                    max.iter   = 200,   # max number of iterations
                    balanced   = T      # whether adjust for unbalanced sample sizes of the two classes
                    ) {

  cv <- gen.cv.idx(nrow(X), K = K)      # generate cv index

  cl <- parallel::makeCluster(K)
  doParallel::registerDoParallel(cl)

  cv.error <- foreach::foreach(k = 1:K, .combine = rbind, .errorhandling = 'pass') %dopar% {
    ## source('iLDA.R', local = TRUE)
    ## source('classify.R', local = TRUE)

  ## for (k in 1:K) {
    error.vec <- NULL
    itr <- 1
    for (i in 1:length(alpha.grid)) {
      for (j in 1:length(lambda.grid)) {
        alpha  <- alpha.grid[i]
        lambda <- lambda.grid[j]

        out <- iLDA(Y        = Y[cv[[k]]$train],
                    X        = X[cv[[k]]$train, ],
                    group    = group,
                    alpha    = alpha,
                    lambda   = lambda,
                    missing  = missing,
                    robust   = robust,  # if use robust estimator for mu and Sigma
                    k        = k,       # wisorized factor in the Huber estimator
                    tol      = tol,     # tolerance level for convergence
                    max.iter = max.iter # max number of iterations
                    )

        if (!out$converge) {
          error.vec[itr] <- 99999
        } else {
          Y.pred <- classify(obj = out,
                             new.X = X[cv[[k]]$test, ],
                             balanced = balanced)

          error <- mean((Y.pred - Y[cv[[k]]$test])^2)
          error.vec[itr] <- error
        }
        itr <- itr + 1
      }
    }
    return(error.vec)
  }

  parallel::stopCluster(cl)

  cv.error <- colMeans(cv.error)

  # generate reference grid of hyperparameters
  all.grid           <- expand.grid(list(lambda.grid, alpha.grid))
  all.grid[, 1:2]    <- all.grid[, 2:1]
  cv.error           <- cbind(all.grid, cv.error)
  colnames(cv.error) <- c('alpha', 'lambda', 'error')

  best.combination <- cv.error[which.min(cv.error[, 'error']), ]

  return(list(best.alpha  = best.combination$alpha,  # best choice of alpha
              best.lambda = best.combination$lambda, # best choice of lambda
              cv.error    = cv.error                 # matrix of cv errors
              ))
}
