softhres <- function(x, thr){
  sign(x) * ifelse(abs(x) > thr, abs(x), 0)
}
