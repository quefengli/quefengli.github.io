#' @title Solve the interative linear discriminant analysis problem
#' @description Solve the interative linear discriminant analysis (iLDA) problem via a proximal gradient algorithm.
#' @details The function solves a regularized minimization problem \deqn{\hat{\beta} = \mathrm{argmin}_{\beta} ~
#'   \frac{1}{2} \beta^T\hat{\Sigma}\beta - (\hat{\mu}_0-\hat{\mu}_1)^T\beta + \lambda \left(\sum_{j\in \mathcal{N}}
#'   ||\beta_{S_j}||_1 + \sum_{j\in \mathcal{M}} ||\beta_{S_j}||_{G}\right),} where \eqn{\hat{\Sigma}} is the pooled
#'   estimator of covariance of the two classes, \eqn{\hat{\mu}_0} and \eqn{\hat{\mu}_1} are the estimators of the means
#'   of the two classes. \eqn{\mathcal{N}} is the set of variables appearing in only one modality. An \eqn{L_1} penalty is
#'   imposed on these variables. \eqn{\mathcal{M}} is the set of variables appearing in multiple modalities. A sparse
#'   group Lasso penalty imposed on these variables. Such a penalty is defined as \deqn{||\beta_{S_j}||_{G} =
#'   (1-\alpha)||\beta_{S_j}||_{1} + \alpha||\beta_{S_j}||_{2}, \quad \alpha\in [0, 1].}
#' @param Y a vector of class labels.
#' @param X a matrix of samples. The dimension is \eqn{nobs * nvars}, where \eqn{nobs} is the sample size in the training
#'   set and \eqn{nvars} is number of features in all modalities. In practice, \code{cbind} data from all modalities to
#'   render \code{X}.
#' @param group a list of group indices. Each element in the list is the column indices of variables belonging to that
#'   group in \code{X} . See an example in \code{Examples} of \code{\link{iLDA}}.
#' @param alpha the tuning parameter \eqn{\alpha}.
#' @param lambda the tuning parameter \eqn{\lambda}.
#' @param missing a logical flag of whether \code{X} contains missing values.
#' @param robust a logical flag of whether using robust estimators for \eqn{\mu_0}, \eqn{\mu_1} and \eqn{\Sigma}. If
#'   \code{TRUE}, the Huber robust estimators will be used. For more details, please see the reference.
#' @param k robustification factor in the Huber estimator.
#' @param tol tolerance level for stopping the algorithm.
#' @param max.iter maximum number of iterations allowed.
#' @return a list with elements \item{beta}{solution of the iLDA problem.} \item{mu0}{estimator of \eqn{\mu_0}.}
#'   \item{mu1}{estimator of \eqn{\mu_1}.} \item{mu}{estimator of \eqn{(\mu_0 + \mu_1) / 2.}} \item{Sigmahat}{estimator of
#'   \eqn{\Sigma}.} \item{w0}{estimator of log odds of the prior probabilities of the two classes,
#'   i.e. \eqn{\log(\hat{\pi}_0 / \hat{\pi}_1).}} \item{iter.count}{actual number of iterations.} \item{converge}{a
#'   logical flag of whether the algorithm converges.}
#' @import Matrix
#' @import robustbase
#' @export
#' @examples
#' \dontrun{
#' ## A toy simulation
#' library(MASS)
#'  
#' n          <- 50                        # sample size
#' p          <- 100                       # number of variables in each modality
#' M          <- 3                         # number of modalities
#' percentage <- 0.2                       
#' share      <- p * percentage            
#'  
#' Sigma <- matrix(1, M * p, M * p)        # true covariance matrix 
#' for (i in 1:(M * p)) {
#'   for (j in 1:(M * p)) {
#'     Sigma[i, j] <- 0.8^(abs(i - j))
#'   }
#' }
#'  
#' beta.1 <- c(rep(c(rep(0.3, 2), rep(0, share - 2)), M),
#'             rep(0.3, 4), rep(0, 2 * share - 4))
#' beta   <- rep(beta.1, M)                # true beta
#' delta  <- Sigma %*% beta
#'  
#' group <- vector('list', 2 * p)          # generate group indices 
#' # modality 1 
#' for (i in 1:(M * share)) {
#'   group[[i]] <- i
#' }
#' for (i in (4 * share + 1):(6 * share)) {
#'   group[[i]] <- i - share
#' }
#' # modality 2
#' for (i in 1:(2 * share)) {
#'   group[[i]] <- c(group[[i]], p + i)
#' }
#' for (i in (M * share + 1):(4 * share)) {
#'   group[[i]] <- p - share + i
#' }
#' for (i in (6 * share + 1):(8 * share)) {
#'   group[[i]] <- p - M * share + i
#' }
#' # modality M
#' for (i in 1:share) {
#'   group[[i]] <- c(group[[i]], 2 * p + i)
#' }
#' for (i in (2 * share + 1):(4 * share)) {
#'   group[[i]] <- c(group[[i]], 2 * p - share + i) 
#' }
#' for (i in (8 * share + 1):(10 * share)) {
#'   group[[i]] <- 2 * p - 5 * share + i
#' }
#'  
#' group.ind <- vector('list', p)
#' for (i in 1:p) {
#'   group.ind[[i]] <- i
#' }
#'  
#' ## searching grid of (alpha, lambda)
#' alpha  <- seq(0, 1, len = 2)
#' lambda <- 2^seq(-4, 1, len = 3) 
#'  
#' ## generate training set
#' X.trn <- rbind(mvrnorm(n, mu = rep(0, M * p), Sigma = Sigma),
#'                mvrnorm(n, mu = -delta, Sigma = Sigma))
#' Y.trn <- c(rep(0, n), rep(1, n))
#'  
#' ## generate test set
#' X.tst <- rbind(mvrnorm(n, mu = rep(0, M * p), Sigma = Sigma),
#'                mvrnorm(n, mu = -delta, Sigma = Sigma))
#' Y.tst <- c(rep(0, n), rep(1, n))
#'  
#' ## cv and fit
#' cv <- cv.iLDA(Y.trn, X.trn, group, alpha, lambda)
#'  
#' fit <- iLDA(Y.trn, X.trn, group,
#'             alpha = cv$best.alpha, 
#'             lambda = cv$best.lambda)
#'
#' ## prediction
#' Y.prd <- classify(fit, X.tst)
#' (error.rate <- sum((Y.tst - Y.prd)^2) / length(Y.tst))
#'  
#' ## generate training set with block missing values
#' missing.prob <- 0.05 
#' X.trn.missing <- cbind(X.trn[, 1:p] * ifelse(rbinom(n, 1, missing.prob) == 1, NA, 1),
#'                        X.trn[, (p + 1):(2 * p)] * ifelse(rbinom(n, 1, missing.prob) == 1, NA, 1),
#'                        X.trn[, (2 * p + 1):(3 * p)] * ifelse(rbinom(n, 1, missing.prob) == 1, NA, 1))
#' ## cv and fit
#' cv <- cv.iLDA(Y.trn, X.trn.missing, group, alpha, lambda, missing = T)
#'  
#' fit <- iLDA(Y.trn, X.trn.missing, group,
#'             alpha = cv$best.alpha, 
#'             lambda = cv$best.lambda,
#'             missing = T)
#'  
#' ## prediction
#' Y.prd <- classify(fit, X.tst)
#' (error.rate <- sum((Y.tst - Y.prd)^2) / length(Y.tst))
#' }

iLDA <- function(Y,               # binary response
                 X,               # features for classification
                 group,           # list of group membership
                 alpha,           # tuning parameter alpha
                 lambda,          # tuning parameter lambda
                 missing  = F,    # if there are missing values in X
                 robust   = F,    # if use robust estiamtor for mu and Sigma
                 k        = 1.345,# wisorized factor in the Huber estimator
                 tol      = 1e-3, # tolerance level for convergence
                 max.iter = 200   # max number of iterations
                 ) {
  n <- nrow(X)
  NumOfGroup <- length(group)

  beta.init  <- rep(0, ncol(X))

  ## if robust estiamtors are needed, use huber estimator
  if (robust){
    X0 <- as.matrix(X[Y == 0,])
    X1 <- as.matrix(X[Y == 1,])
    X0[is.na(X0)] <- 0
    X1[is.na(X1)] <- 0
    mu0   <- apply(X0, 2, function(x) huberM(x, k = k)$mu)
    mu1   <- apply(X1, 2, function(x) huberM(x, k = k)$mu)
    delta <- mu0 - mu1
    mu    <- (mu1 + mu0)/2

    ## if there are missing values, find the positive definite matrix nearest to cov(X)
    if (missing == F) {
      t1       <- apply(X^2, 2, function(x) huberM(x, k = k)$mu)
      t2       <- apply(X, 2, function(x) huberM(x, k = k)$mu)^2
      v        <- diag(t1 - t2)
      Sigmahat <- v %*% cor(X, method = 'kendall') %*% v
    } else {
      t1       <- apply(X^2, 2, function(x) huberM(x, k = k)$mu)
      t2       <- apply(X, 2, function(x) huberM(x, k = k)$mu)^2
      v        <- diag(t1 - t2)
      Sigmahat <- Matrix::nearPD(v %*% cor(X, method = 'kendall', use = 'pairwise.complete.obs') %*% v, doSym = T)$mat
    }
  } else {
    mu0   <- colMeans(as.matrix(X[Y == 0,]), na.rm = T)
    mu1   <- colMeans(as.matrix(X[Y == 1,]), na.rm = T)
    delta <- mu0 - mu1
    mu    <- (mu1 + mu0)/2

    ## if there are missing values, find the positive definite matrix nearest to cov(X)
    if (missing == F) {
      Sigmahat <- cov(X)
    } else {
      Sigmahat <- Matrix::nearPD(cov(X, use = 'pairwise.complete.obs'), doSym = T)$mat
    }
  }


  stepsize <- .8 / max(eigen(Sigmahat)$val) # stepsize should be smaller than 1 / max(eigen(Sigmahat)$val)
  p0 <- mean(Y == 0)
  p1 <- mean(Y == 1)

  w0 <- log(p0 / p1)

  iter.count <- 0
  beta.old   <- rep(999, length(beta.init))
  beta.new   <- beta.init

  while((sqrt(sum( beta.old - beta.new )^2) >= tol) & (iter.count <= max.iter)){
    iter.count <- iter.count + 1
    beta.old   <- beta.new
    gradient   <- Sigmahat %*% beta.old - delta

    for (j in 1:NumOfGroup) {
      if (length(group[[j]]) > 1) {
        z <- softhres(beta.old[group[[j]]] - stepsize * gradient[group[[j]]], stepsize * (1 - alpha) * lambda)
        z.norm <- sqrt(sum(z^2))
        if(z.norm > stepsize * alpha * lambda){
          beta.new[group[[j]]] <- z * (1 - stepsize * alpha * lambda / z.norm)
        } else {
          beta.new[group[[j]]] <- rep(0, length(z))
        }
      }
      else{
        beta.new[group[[j]]] <- softhres(beta.old[group[[j]]] - stepsize * gradient[group[[j]]], stepsize * lambda)
      }
    }
  }

  return(list(beta       = beta.new,               # estimated beta
              mu0        = mu0,                    # mean of class 0
              mu1        = mu1,                    # mean of class 1
              mu         = mu,                     # (mu0 + mu1) / 2
              ## delta      = delta,                  # mu0 - mu1
              Sigmahat   = Sigmahat,               # estimate of Sigma
              w0         = w0,                     # log ratio of sample sizes of the two classes
              ## stepsize   = stepsize,               # step size
              iter.count = iter.count,             # actual number of iterations
              converge   = (iter.count < max.iter) # whether convergence is achieved
              ))
}
