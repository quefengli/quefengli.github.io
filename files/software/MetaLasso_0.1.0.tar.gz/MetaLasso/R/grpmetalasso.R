#' @title Solve the group MetaLasso problem with a single tuning parameter
#' @description Jointly fit a generalized linear model with a group penalty over multiple datasets. It enables both group
#'   selections and within-group variable selections over multiple datasets. Fits linear, logistic and multinomial,
#'   poisson, and Cox regression models.
#' @details The function minimizes \eqn{-logLik + lambda * p(beta)}, where \eqn{-logLik} is the negative of the total
#'   log-Likelihood from all datasets, \eqn{lambda} is a single tuning parameter and \eqn{p(beta)} is a specific group
#'   penalty function enabling both group selections and within-group variable selections over multiple datasets. For more
#'   details of the penalty function, see the reference below.
#' @param X.all a concatenated design matrix, of dimension \eqn{nobs * nvars}, where nobs is the total sample size over
#'   multiple datasets and nvars is the total number of variables.
#' @param Y.all a concatenated response vector from all datasets
#' @param obs a vector of sample sizes of multiple datasets
#' @param groups a matrix, of dimension \eqn{ngrps * nvars}, indexing the group membership of variables. The \eqn{(i,
#'   j)}-th element of groups = 1, if the \eqn{j}-th variable belongs to the \eqn{i}-th group; = 0, otherwise. A variable
#'   is allowed to belong to multiple groups.
#' @param lambda a tuning parameter of penalty
#' @param family response type (see above)
#' @param maxit maximal number of iterations allowed
#' @param tol tolerance level of convergence
#' @return a list of following components \item{coe}{estimated coefficients in each dataset} \item{grp.coe}{estimated
#'   group effects. For more details, see the reference below.} \item{iteration}{number of iterations}
#'   \item{converge}{\code{TRUE} if convergence is achieved} \item{diff}{last step difference}
#' @import glmnet
#' @references Li, Q., Yu, M., and Wang,
#'   S. (2017). \href{http://www.bios.unc.edu/~quefeng/publication/JMVA2017.pdf}{A Statistical Framework for Pathway
#'   and Gene Identification from Integrative Analysis.} \emph{Journal of Multivariate Analysis}, 156:1-17.
#' @examples
#' dign <- function(m1, m2){
#'   rbind(cbind(m1, matrix(rep(0, nrow(m1)*ncol(m2)), nrow = nrow(m1))),
#'         cbind(matrix(rep(0, nrow(m2)*ncol(m1)), nrow = nrow(m2)), m2))
#' }
#'  
#' M        <- 10                            # number of datasets
#' n.m      <- rep(50, M)                    # number of n.m in each dataset
#' p        <- 100                           # number of covariates
#' K        <- p/5                           # number of pathways
#' nonzero  <- 25                            # number of nonzero coefficients
#' means    <- c(rep(8, 5), rep(8, 5), 
#'               rep(-4, 5), rep(-4, 5), rep(-8, 5), 
#'               rep(0, p - nonzero))        # means of nonzero beta's  
#' sig      <- c(rep(0.5, nonzero), rep(0, p - nonzero)) # sds of nonzero beta's
#'  
#' groups <- matrix(rep(1, 5), nrow = 1)   # group structure
#' for (i in 1:(K-1)) {
#'   groups <- dign(groups, matrix(rep(1, 5), nrow = 1))
#' }
#'  
#' ## generate beta
#' beta <- NULL    
#' for (i in 1:p){
#'   beta <- cbind(beta, rnorm(M, means[i], sig[i]))
#' }
#'  
#' ## generate X.ll and Y.ll
#' X.all <- NULL                          
#' Y.all <- NULL                          
#' for (m in 1:M){
#'   X.tmp <- matrix(scale(matrix(rnorm(n.m[m] * p), n.m[m], p)), n.m[m], p)
#'   X.all <- rbind(X.all, X.tmp)
#'   pb <- X.tmp %*% beta[m, ]
#'   pb <- exp(pb) / (1 + exp(pb))
#'   Y.tmp <- matrix(rbinom(n.m[m], 1, pb), ncol = 1)
#'   Y.all <- rbind(Y.all, Y.tmp)
#' }
#' Y.all <- as.vector(Y.all)
#'  
#' ## range of tuning parameters
#' lams    <- 2^seq(-3, -1, len = 10)
#'  
#' BIC <- NULL
#' for (i in 1:length(lams)) {
#'   fit <- grpmetalasso(X.all, Y.all, obs = n.m, groups = groups, family = 'binomial', lambda = lams[i])
#'   BIC[i] <- bic(X.all, Y.all, n.m, fit$coe)
#' }
#'  
#' best.fit <- grpmetalasso(X.all, Y.all, obs = n.m, groups = groups, family = 'binomial',
#'                          lambda = which.min(BIC))
#' @export

grpmetalasso <- function(X.all, Y.all, obs, groups, lambda,
                         family = c("gaussian","binomial","poisson","multinomial","cox","mgaussian"),
                         maxit = 100, tol = 1e-3){ 
  ## starting and ending index of each dataset
  start.idx   <- cumsum(obs) + 1 - obs    # starting index of each dataset
  end.idx     <- cumsum(obs)              # ending index of each dataset
  M           <- length(start.idx)        # number of datasets
  p           <- ncol(X.all)              # number of covariates
  N           <- sum(obs)                 # total number of obserations
  K           <- nrow(groups)             # number of groups
  gamma       <- matrix(NA, p, maxit + 1) # iterations of gamma
  unadj.gamma <- matrix(NA, K, maxit + 1) # iterations of unadjusted gamma
  rho         <- matrix(NA, p, maxit + 1) # iterations of rho
  gamma[, 1]  <- rep(1, p)
  rho[, 1]    <- rep(1, p)
  theta       <- matrix(NA, M * p, maxit) # iterations of theta
  X.tha       <- matrix(NA, N, p)         # colMultiply(X.all, theta)
  beta.hat    <- vector("list", M)        # iterations of beta.hat
  coef        <- vector("list", M)        # final estimate of coefficients
  itr         <- 1
  m.diff      <- NULL                     # marginal error
  
  for (m in 1:M){
    beta.hat[[m]] <- matrix(NA, p, maxit)
  }

  while(!(itr > maxit)){
    ## Iterate as: theta --> rho --> gamma --> theta
    for (m in 1:M){
      ## In each dataset, fit Y.all ~ colMultiply(X.all, gamma*rho)
      
      theta.fit <- glmnet(t(t(X.all[start.idx[m]:end.idx[m], ]) *
                              gamma[, itr] * rho[, itr]),
                          Y.all[start.idx[m]:end.idx[m]],
                          alpha = 1, family = family, 
                          lambda = lambda,
                          standardize = FALSE)
      theta[((m - 1) * p + 1):(m * p), itr] <- as.vector(theta.fit$beta)
      
      ## adjust X.all by colMultiply(X.all, theta) for further usage
      X.tha[start.idx[m]:end.idx[m], ] <- t(t(X.all[start.idx[m]:end.idx[m], ]) *
                                              as.vector(theta.fit$beta))
      
      beta.hat[[m]][, itr] <- theta[((m - 1) * p + 1):(m * p), itr] * rho[, itr] *
        gamma[, itr]
      ## calculate iteration difference
      if (itr == 1) {
        m.diff[m] <- max(abs(beta.hat[[m]][, itr]))
      }
      else {
        m.diff[m] <- max(abs(beta.hat[[m]][, itr] - beta.hat[[m]][, itr - 1]))
      }
    }
    
    if(max(m.diff) < tol) break         # break iterations if diff < tol
    
    itr <- itr + 1
    
    ## calculate rho values
    rho.fit <- glmnet(t(t(X.tha) * gamma[, itr - 1]),     # take care of X 
                      Y.all, 
                      alpha = 1, family = family, 
                      lambda = 1 / sum(obs),
                      standardize = FALSE)
    rho[, itr] <- as.vector(rho.fit$beta)
    
    ## calculate gamma values: some columns of X.all should be combined
    ## according to pathway layouts. The fitted value is K-dimesional (not
    ## p-dimensional) 
    gamma.fit <- glmnet(t(t(X.tha) * rho[, itr]) %*% t(groups), 
                        Y.all,
                        alpha = 1, family = family, 
                        lambda = 1 / sum(obs),
                        standardize = FALSE)
    unadj.gamma[, itr] <- as.vector(gamma.fit$beta)
    ## map the K-dimensional fitted value to p-dimensional value
    gamma[, itr] <- as.vector(gamma.fit$beta) %*% groups
  }


  ## determine if convergence is achieved
  if (itr == 1) {
    iteration <- itr
    converge  <- FALSE
  }
  else {
    if (itr > maxit) {
      iteration <- itr - 1
      converge  <- FALSE
    }
    else {
      iteration <- itr
      converge  <- TRUE
    }  
  }
  for (m in 1:M){
    coef[[m]] <- beta.hat[[m]][, iteration]
  }
  
  return(list(coe        = coef,
              grp.coe    = unadj.gamma[, iteration], 
              iteration  = iteration,
              converge   = converge,
              diff       = max(m.diff)
              ))
}
