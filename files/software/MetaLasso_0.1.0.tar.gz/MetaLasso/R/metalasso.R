#' @title Solve the MetaLasso problem with a single tuning parameter
#' @description Jointly fit a generalized linear model with a penalty over multiple datasets. It enables heterogeneous
#'   variable selections in different datasets. Fits linear, logistic and multinomial, poisson, and Cox regression models.
#' @details The function minimizes \eqn{-logLik + lambda * p(beta)}, where \eqn{-logLik} is the negative of the total
#'   log-Likelihood from all datasets, \eqn{lambda} is a single tuning parameter and \eqn{p(beta)} is a specific penalty
#'   function enabling heterogeneous selections of variables in different datasets. For more details of the penalty
#'   function, see the reference below.
#' @param X.all a concatenated design matrix, of dimension \eqn{nobs * nvars}, where nobs is the total sample size over
#'   multiple datasets and nvars is the total number of variables.
#' @param Y.all a concatenated response vector from all datasets
#' @param obs a vector of sample sizes of multiple datasets
#' @param lambda a tuning parameter of penalty
#' @param family response type (see above)
#' @param maxit maximal number of iterations allowed
#' @param tol tolerance level of convergence
#' @return a list of the following components \item{coe}{estimated coefficients in each dataset} \item{iteration}{number
#'   of iterations} \item{converge}{\code{TRUE} if convergence is achieved} \item{diff}{last step difference}
#' @import glmnet
#' @references Li, Q., Wang, S., Huang, C., Yu, M., and Shao,
#'   J. (2014). \href{http://www.bios.unc.edu/~quefeng/publication/Biometrics2014.pdf}{Meta Analysis Based Variable
#'   Selection for Gene Expression Data.} \emph{Biometrics}, 70:872-880.
#' @examples
#' n   <- 50
#' p   <- 100 
#' M   <- 5   
#' obs <- rep(n, M)
#'  
#' X.all <- NULL
#' Y.all <- NULL
#'  
#' for (m in 1:M) {
#'     X.tmp <- matrix(scale(matrix(rnorm(obs[m] * p), obs[m], p)), obs[m], p)
#'     X.all <- rbind(X.all, X.tmp)
#'     beta  <- c(1, -1, 2, -1, rep(0, p - 4))
#'     pb    <- X.tmp %*% beta
#'     pb    <- exp(pb) / (1 + exp(pb))
#'     Y.tmp <- matrix(rbinom(obs[m], 1, pb), ncol = 1)
#'     Y.all <- c(Y.all, Y.tmp)
#' }
#'  
#' lams <- seq(0.01, 0.08, len = 10)
#' BIC  <- NULL
#' for (j in 1:length(lams)) {
#'   fit <- metalasso(X.all, Y.all, obs, family = 'binomial', lambda = lams[j])
#'   BIC[j] <- bic(X.all, Y.all, obs, fit$coe)
#' }
#'  
#' best.fit <- metalasso(X.all, Y.all, obs, lambda = lams[which(BIC == min(BIC))], family = 'binomial')

#' @export

metalasso <- function(X.all, Y.all, obs, lambda,
                      family = c("gaussian","binomial","poisson","multinomial","cox","mgaussian"),
                      maxit = 100, tol = 1e-3){
  ## starting and ending index of each dataset
  start.idx   <- cumsum(obs) + 1 - obs    # starting index of each dataset
  end.idx     <- cumsum(obs)              # ending index of each dataset
  M           <- length(start.idx)        # number of datasets
  p           <- ncol(X.all)              # number of covariates
  N           <- sum(obs)                 # total number of obserations
  gamma       <- matrix(NA, p, maxit + 1) # iterations of gamma
  gamma[, 1]  <- rep(1, p)
  theta       <- matrix(NA, M * p, maxit) # iterations of theta
  X.tha       <- matrix(NA, N, p)         # colMultiply(X.all, theta)
  beta.hat    <- vector("list", M)        # iterations of beta.hat
  coef        <- vector("list", M)        # final estimate of coefficients
  itr         <- 1
  m.diff      <- NULL                     # marginal error
  for (m in 1:M){
    beta.hat[[m]] <- matrix(NA, p, maxit)
  }
  
  
  while(!(itr > maxit)){
    for (m in 1:M){
      theta.fit <- glmnet(t(t(X.all[start.idx[m]:end.idx[m], ]) * 
                              gamma[, itr]),
                          Y.all[start.idx[m]:end.idx[m]],
                          alpha = 1, 
                          family = family, 
                          lambda = lambda,
                          standardize = FALSE)
      
      theta[((m - 1) * p + 1):(m * p), itr] <- as.vector(theta.fit$beta)
      
      ## adjust X.all by colMultiply(X.all, theta) for further usage
      X.tha[start.idx[m]:end.idx[m], ] <- t(t(X.all[start.idx[m]:end.idx[m], ]) *
                                              as.vector(theta.fit$beta))

      beta.hat[[m]][, itr] <- theta[((m - 1) * p + 1):(m * p), itr] * gamma[, itr]
      ## calculate iteration difference
      if (itr == 1) {
        m.diff[m] <- max(abs(beta.hat[[m]][, itr]))
      }
      else {
        m.diff[m] <- max(abs(beta.hat[[m]][, itr] - beta.hat[[m]][, itr - 1]))
      }
    }
    
    if(max(m.diff) < tol) break         # break iterations if diff < tol

    itr <- itr + 1
    
    gamma.fit <- glmnet(X.tha, Y.all, alpha = 1, family = family, 
                        lambda = 0.1, 
                        standardize = FALSE)
    gamma[, itr] <- as.vector(gamma.fit$beta)
  }
  
  ## determine if convergence is achieved
  if (itr == 1) {
    iteration <- itr
    converge  <- FALSE
  }
  else {
    if (itr > maxit) {
      iteration <- itr - 1
      converge  <- FALSE
    }
    else {
      iteration <- itr
      converge  <- TRUE
    }  
  }

  for (m in 1:M){
    coef[[m]] <- beta.hat[[m]][, iteration]
  }
  
  return(list(coe         = coef,
              iteration   = iteration,
              converge    = converge,
              diff        = max(m.diff)
              ))
}


