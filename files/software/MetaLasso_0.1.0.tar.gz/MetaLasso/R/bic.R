bic <- function(X.all, Y.all, obs, coef){
  start.idx <- cumsum(obs) + 1 - obs    # starting index of each dataset
  end.idx   <- cumsum(obs)              # ending index of each dataset
  M         <- length(coef)
  value     <- 0
  for (m in 1:M) {
    prob <- X.all[start.idx[m]:end.idx[m], ] %*% coef[[m]]
    prob <- exp(prob) / (1 + exp(prob))
    too.small <- prob < 1e-10
    too.large <- prob > (1 - 1e-10)
    prob[too.small] <- 1e-10
    prob[too.large] <- 1 - 1e-10
    p <- sum(coef[[m]] != 0)
    value <- value +
      sum(Y.all[start.idx[m]:end.idx[m]] * log(prob)
          + (1 - Y.all[start.idx[m]:end.idx[m]]) * log(1 - prob)) /
      obs[m] * ( - 2) + p * (log(obs[m]) + 2 * log(ncol(X.all)))/ obs[m]
  }
  return(value)
}
