source("generate.R")
source("our.R")

## seed handling
seed     <- as.integer(abs(rnorm(1)*100000))
set.seed(seed)
filename <- paste("simu",seed,".RData",sep="")

## calculation of d.plus and d.mnus
## catch exception when denominator equals to 0
d.plus <- function(Y, Trt, X, beta){
  val <- sum(Y * (Trt == 1 & !(X %*% beta < 0))) /
    sum((Trt == 1 & !(X %*% beta < 0))) -
      sum(Y * (Trt == 0 & !(X %*% beta < 0))) /
        sum((Trt == 0 & !(X %*% beta < 0)))
  return(val)
}

d.mnus <- function(Y, Trt, X, beta){
  val <- sum(Y * (Trt == 0 &  (X %*% beta < 0))) /
    sum((Trt == 0 &  (X %*% beta < 0))) -
      sum(Y * (Trt == 1 &  (X %*% beta < 0))) /
        sum((Trt == 1 &  (X %*% beta < 0)))
}

n <- 500                             # sample size
m <- round(n^0.8, digits=0)          # size of bootstrap samples
B <- 1000                            # number of bootstrap resampling
N <- 100000                          # test sample size

## model specifications
raw <- data.frame(Trt = relevel(as.factor(sample(0:1, n, replace = T)), ref = 2),
                  a   = relevel(as.factor(sample(0:3, n, replace = T)), ref = 4),
                  b   = relevel(as.factor(sample(0:3, n, replace = T)), ref = 4),
                  c   = relevel(as.factor(sample(0:3, n, replace = T)), ref = 4),
                  d   = relevel(as.factor(sample(0:3, n, replace = T)), ref = 4),
                  e   = relevel(as.factor(sample(0:3, n, replace = T)), ref = 4),
                  A   = relevel(as.factor(sample(0:1, n, replace = T)), ref = 2),
                  B   = relevel(as.factor(sample(0:1, n, replace = T)), ref = 2),
                  C   = relevel(as.factor(sample(0:1, n, replace = T)), ref = 2),
                  D   = relevel(as.factor(sample(0:1, n, replace = T)), ref = 2),
                  E   = relevel(as.factor(sample(0:1, n, replace = T)), ref = 2),
                  Ca  = rnorm(n)
                  )
## Model (A)
true.names <- c("b3", "c3", "Trt1:a2", "Trt1:a3", "Trt1:A1:B1")
true.value <- c(1, 1, 5, 5, 5)
dat <- generate(raw, true.names, true.value)

## fit by our algorithm
fit <- our(dat,
           grp.lasso.lbd = sort(2^seq(0, 4, len = 3), decreasing = T),
           lasso.lbd = 2^(seq(-3, 3, len = 20)),
           refit = T
           )

## E of d.plus and d.minus of population, estimated by a very large sample
true.raw <- data.frame(Trt = relevel(as.factor(sample(0:1, N, replace = T)), ref = 2),
                       a   = relevel(as.factor(sample(0:3, N, replace = T)), ref = 4),
                       b   = relevel(as.factor(sample(0:3, N, replace = T)), ref = 4),
                       c   = relevel(as.factor(sample(0:3, N, replace = T)), ref = 4),
                       d   = relevel(as.factor(sample(0:3, N, replace = T)), ref = 4),
                       e   = relevel(as.factor(sample(0:3, N, replace = T)), ref = 4),
                       A   = relevel(as.factor(sample(0:1, N, replace = T)), ref = 2),
                       B   = relevel(as.factor(sample(0:1, N, replace = T)), ref = 2),
                       C   = relevel(as.factor(sample(0:1, N, replace = T)), ref = 2),
                       D   = relevel(as.factor(sample(0:1, N, replace = T)), ref = 2),
                       E   = relevel(as.factor(sample(0:1, N, replace = T)), ref = 2),
                       Ca  = rnorm(N)
                       )
true.dat  <- generate(true.raw, true.names, true.value)

true.plus <- d.plus(true.dat$Y, true.dat$Trt, true.dat$X, fit$beta.hat)
true.mnus <- d.mnus(true.dat$Y, true.dat$Trt, true.dat$X, fit$beta.hat)

## bootstrap distribution of d.plus and d.minus
boot.plus <- NULL
boot.mnus <- NULL
aic.reach.boundary <- NULL
for (b in 1:B) {
  idx   <- sample(1:n, size = m, replace = TRUE)
  b.raw <- raw[idx, ]
  b.dat <- generate(b.raw, true.names, true.value)
  b.fit <- our(b.dat,
               grp.lasso.lbd = sort(2^seq(0, 4, len = 3), decreasing = T),
               lasso.lbd = 2^(seq(-3, 3, len = 20)),
               refit = F
               )
  boot.plus[b] <- d.plus(b.dat$Y, b.dat$Trt, b.dat$X, b.fit$beta.hat)
  boot.mnus[b] <- d.mnus(b.dat$Y, b.dat$Trt, b.dat$X, b.fit$beta.hat)
  aic.reach.boundary[b] <- min(b.fit$lasso.aic) == b.fit$lasso.aic[1] | min(b.fit$lasso.aic) ==
    tail(b.fit$lasso.aic, 1)
}

q <- c(0.025, 0.975)
boot.plus.low <- unname(quantile(boot.plus, q[1], na.rm = TRUE))
boot.plus.hgh <- unname(quantile(boot.plus, q[2], na.rm = TRUE))
boot.mnus.low <- unname(quantile(boot.mnus, q[1], na.rm = TRUE))
boot.mnus.hgh <- unname(quantile(boot.mnus, q[2], na.rm = TRUE))

boot.plus.is.cover <- !(boot.plus.low > true.plus) & !(true.plus > boot.plus.hgh)
boot.mnus.is.cover <- !(boot.mnus.low > true.mnus) & !(true.mnus > boot.mnus.hgh)


save(true.plus, true.mnus,
     boot.plus, boot.mnus,
     boot.plus.low, boot.plus.hgh,
     boot.mnus.low, boot.mnus.hgh,
     boot.plus.is.cover, boot.mnus.is.cover,
     aic.reach.boundary,
     fit,
     file = filename)

