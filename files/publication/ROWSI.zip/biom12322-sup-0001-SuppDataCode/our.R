library(grplasso)
library(penalized)
source("generate.R")

our <- function(dat, grp.lasso.lbd, lasso.lbd, refit = TRUE){
  X   <- dat$X[dat$Y == 1, ]
  Trt <- as.numeric(dat$Trt[dat$Y == 1]) - 1
  
  ## extract names of multi-level, binary and continuous covariates
  mul <- unique(gsub("[0-9]", "", grep("^[a-z][0-9]$", colnames(dat$X), value = T)))
  bin <- unique(gsub("[0-9]", "", grep("^[A-Z][0-9]$", colnames(dat$X), value = T)))
  con <- unique(gsub("[0-9]", "", grep("^[A-Z][a-z]$", colnames(dat$X), value = T)))

  ## calculate levels of each multi-level and binary factors
  mul.levels <- unlist(lapply(mul, function(x)
                              length(grep(paste("^", x, "[0-9]$", sep = ""),
                                          colnames(dat$X)))))
  bin.levels <- unlist(lapply(bin, function(x)
                              length(grep(paste("^", x, "[0-9]$", sep = ""),
                                          colnames(dat$X)))))
  
############## prepare indices for group lasso fit ##############################
  if(length(con) > 0){
    levels <- c(mul.levels, bin.levels, rep(1, length(con)))
  } else {
    levels <- c(mul.levels, bin.levels)
  }

  intr <- NULL
  for (i in 1:(length(levels) - 1)){
    for (j in (i + 1) : length(levels)){
      intr <- c(intr, levels[i] * levels[j])
    }
  }

  idx.intr <- NULL
  for (i in 1:length(intr)){
    idx.intr <- c(idx.intr, rep(i + 1 + sum(levels), intr[i]))
  }

  grp.lasso.idx <- c(rep(NA, 1 + sum(levels)), idx.intr)

#################### 1st step: grp lasso to choose important interactions #######################
  grp.lasso.fit <- grplasso(X, Trt, index = grp.lasso.idx, lambda = grp.lasso.lbd,
                            model = LogReg(), penscale = sqrt,
                            control = grpl.control(update.hess = "lambda", trace = 0))
  grp.lasso.nz.beta <- apply(grp.lasso.fit$coe != 0, 2, sum)
  grp.lasso.aic <- (-2) * grp.lasso.fit$nloglik + 2 * grp.lasso.nz.beta           # aic of each fit

  grp.lasso.pck <- which(grp.lasso.aic == min(grp.lasso.aic, na.rm = T))
  grp.lasso.slc <- names(which(grp.lasso.fit$coe[, grp.lasso.pck] != 0))[-1]# selected interactions


############################## 2nd step: fit a lasso ############################################
  lasso.aic   <- NULL
  lasso.betas <- matrix(NA, length(lasso.lbd), length(grp.lasso.slc) + 1)

  for (i in 1:length(lasso.lbd)) {
    lasso.fit <- try(penalized(Trt, penalized = X[, which(colnames(X) %in% (grp.lasso.slc))],
                               lambda1   = lasso.lbd[i],
                               fusedl    = FALSE, model = "logistic",
                               ##startbeta = rep(0, length(grp.lasso.slc)),
                               positive  = FALSE,  trace = FALSE, standardize = FALSE))
    if (class(lasso.fit) == "try-error") {
      if(i < length(lasso.lbd)) next
      else break
    } else {
      ## lasso.betas[i, ] <- round(lasso.fit@penalized, digits = 4)
      lasso.betas[i, ] <- c(lasso.fit@unpenalized, lasso.fit@penalized)
      lasso.aic[i] <- (-2 * lasso.fit@loglik + 2 * (sum(lasso.betas[i, ] != 0) - 1))
    }
  }

  lasso.pck <- min(which(lasso.aic == min(lasso.aic, na.rm = T)))
  lasso.coe <- lasso.betas[lasso.pck, ]
  lasso.slc <- grp.lasso.slc[lasso.coe[-1] != 0]
  
  lasso.beta.hat <- rep(0, ncol(dat$X))
  lasso.beta.hat[colnames(dat$X) %in% c("(Intercept)", grp.lasso.slc)] <- lasso.coe
  names(lasso.beta.hat) <- colnames(dat$X)
  beta.hat <- lasso.beta.hat

########################## refit by using selected covariates (optional) ########################
  if(refit){
    expr     <- paste(lasso.slc, collapse = " + ")
    expr     <- as.formula(paste("Trt ~ ", expr, sep = ""))
    re.fit   <- glm(expr, family = "binomial", data = data.frame(Trt = dat$Trt, dat$X[, -1]))
    names(re.fit$coef) <- c("(Intercept)", lasso.slc)
    beta.hat <- rep(0, ncol(dat$X))
    beta.hat[colnames(dat$X) %in% names(re.fit$coef)] <- re.fit$coef
    names(beta.hat) <- colnames(dat$X)
  
  }
    
  return(list(selected       = lasso.slc,
              lasso.beta.hat = lasso.beta.hat,
              beta.hat       = beta.hat, 
              grp.lasso.aic  = grp.lasso.aic,
              lasso.aic      = lasso.aic
              ))
}


