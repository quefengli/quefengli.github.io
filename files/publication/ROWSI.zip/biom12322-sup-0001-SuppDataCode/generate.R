generate <- function(raw, true.names, true.value){
  ## generate a data-frame to be input into our main algorithm
  ## Args:
  ## raw  - raw data-frame, consists of binary treatment, binary and multi-level categorical factors and continuous covariates
  ## true.names  - names of significant variables
  ## true.value  - values of significant variables 
  ## Returns:	  
  ## Y	  - response
  ## Trt  - treatment (from raw)
  ## X    - design matrix (including dummy variables for fators) to be input into our main algorithm 		   
  ## true.names  - names of significant variables
  ## beta.dagger - true value of treatment * covariate interaction

  options(contrasts=c("contr.sum", "contr.poly"))
  true.model <- model.matrix( ~ (. - Trt)^2 * Trt, raw)
    
  beta <- rep(0, ncol(true.model))
  names(beta) <- colnames(true.model)
    
  ## a logistic model
  beta[colnames(true.model) %in% true.names] <- true.value
  pr <- exp(true.model %*% beta) / (1 + exp(true.model %*% beta))
  Y  <- rbinom(nrow(raw), 1, pr)

  ## extract beta.dagger from beta
  beta.dagger <- beta[grep("^Trt1", names(beta))]
  names(beta.dagger) <- gsub("^Trt1:?", "", names(beta.dagger))
  names(beta.dagger)[1] <- "(Intercept)"
  
  X <- model.matrix( ~ (. - Trt)^2, raw)
  Trt.ora <- as.numeric(X %*% beta.dagger >= 0)
  return(list(Y           = Y,
              X           = X, 
              Trt         = raw$Trt,
              Trt.ora     = Trt.ora, 
              true.names  = true.names,
              beta.dagger = beta.dagger))
}

