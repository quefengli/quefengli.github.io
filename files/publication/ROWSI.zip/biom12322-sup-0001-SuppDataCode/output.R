output <- function(dat, dat.test, fit){
  ## oracle beta: non-zero elements of beta.dagger
  ora.beta    <- with(dat, beta.dagger[beta.dagger!= 0])
  ora.name    <- names(ora.beta)

  ## sensitivity and specificity
  sens        <- sum(ora.name %in% fit$selected) / length(ora.name)
  spec        <- 1 - sum(!fit$selected %in% ora.name) / (ncol(dat$X) - 1 - length(ora.name))

  ora.X       <- dat$X[, which(colnames(dat$X) %in% ora.name)]
  prod        <- ora.X %*% ora.beta
                                        #rm.id       <- which(prod == 0)
  ## our treatment assignment by using sign(X * beta.hat)
  pred        <- as.numeric(dat$X[, -1] %*% (-fit$beta.hat[-1]) > 0)
  
  ## oracle treatment assignment by using sign(X * ora.beta)
  ora.X       <- dat$X[, which(colnames(dat$X) %in% ora.name)]
  ora.Trt     <- as.numeric(ora.X %*% ora.beta > 0)
 
  ## misclassification rate comparing ours and oracle
  miss        <- sum(ora.Trt != pred) / length(ora.Trt)
 
  imp.var.tbl <- ora.name %in% fit$selected
  names(imp.var.tbl) <- ora.name
  uni.var.tbl <- colnames(dat$X)[-c(1, which(colnames(dat$X) %in% ora.name))] %in% fit$selected
  names(uni.var.tbl) <- colnames(dat$X)[-c(1, which(colnames(dat$X) %in% ora.name))]

  trt.test <- as.numeric(dat.test$Trt.ora)
  Y.test   <- dat.test$Y
  if(prod(fit$beta.hat == 0) == 1)  {
    pred.test  <- rep(1, dim(dat.test$X)[1])
  } else {
    pred.test <- as.numeric(dat.test$X[, -1] %*% (-fit$beta.hat[-1]) > 0)
  }

  
  identi    <- as.numeric(pred.test != trt.test)
  valuef    <- mean((identi * Y.test) * 2)
  identiOra <- as.numeric(trt.test != trt.test)
  valuefOra <- mean((identiOra * Y.test) * 2)

  return(list(ora.beta    = ora.beta,
              ora.name    = ora.name,
              sens        = sens,
              spec        = spec,
              miss        = miss,
              imp.var.tbl = imp.var.tbl,
              uni.var.tbl = uni.var.tbl,
              valuef      = valuef,
              valuefOra   = valuefOra
              ))
}

