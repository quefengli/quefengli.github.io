setwd("C:\\Users\\meyu\\Dropbox\\Yaoyao-Subgroup\\codeExample")
#setwd("/Users/seo/dropbox/Yaoyao-Subgroup/codeExample")

source("generate.R")
source("our.R")
source("output.R")

## seed handling
seed     <- as.integer(abs(rnorm(1)*100000))
set.seed(seed)
filename <- paste("simu", seed, ".RData", sep = "")

## generate data
n <- N <- 500
raw <- data.frame(Trt = as.factor(sample(0:1, n, replace = T)),
                  a   = as.factor(sample(0:3, n, replace = T)),
                  b   = as.factor(sample(0:3, n, replace = T)),
                  c   = as.factor(sample(0:3, n, replace = T)),
                  d   = as.factor(sample(0:3, n, replace = T)),
                  e   = as.factor(sample(0:3, n, replace = T)),
                  A   = as.factor(sample(0:1, n, replace = T)),
                  B   = as.factor(sample(0:1, n, replace = T)),
                  C   = as.factor(sample(0:1, n, replace = T)),
                  D   = as.factor(sample(0:1, n, replace = T)),
                  E   = as.factor(sample(0:1, n, replace = T)),
                  Ca  = rnorm(n)                  )

true.names <- c("C1", "Trt1:B1", "Trt1:a3:A1")
true.value <- c(0.5, 2, 2)
dat <- generate(raw, true.names, true.value)


raw.test <- data.frame(Trt = as.factor(sample(0:1, N, replace = T)),
                  a   = as.factor(sample(0:3, N, replace = T)),
                  b   = as.factor(sample(0:3, N, replace = T)),
                  c   = as.factor(sample(0:3, N, replace = T)),
                  d   = as.factor(sample(0:3, N, replace = T)),
                  e   = as.factor(sample(0:3, N, replace = T)),
                  A   = as.factor(sample(0:1, N, replace = T)),
                  B   = as.factor(sample(0:1, N, replace = T)),
                  C   = as.factor(sample(0:1, N, replace = T)),
                  D   = as.factor(sample(0:1, N, replace = T)),
                  E   = as.factor(sample(0:1, N, replace = T)),
                  Ca  = rnorm(N)
                  )
dat.test <- generate(raw.test, true.names, true.value)

## fit by our method
fit <- our(dat,
           grp.lasso.lbd = sort(2^seq(0, 4, len = 5), decreasing = T),
           lasso.lbd = 2^(seq(-1, 4, len = 10)),
           refit = F
           )

## performance of our method
out <- output(dat, dat.test, fit)

save(fit, out, file = filename)

